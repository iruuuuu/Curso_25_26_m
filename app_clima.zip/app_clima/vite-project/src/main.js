import './style.css'


document.querySelector('#app').innerHTML = `
  <div>
  <h1>hello world</h1>
  </div>
`

setupCounter(document.querySelector('#counter'))
