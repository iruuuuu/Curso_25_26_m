

export function createClimateApp(){
    const container = document.createElement('div')
    container.className= "xxxxx"


    const header = document.createElement('header')
    header.textContent= "ClimateApp"
    container.appendChild(header)
    

    const main = document.createElement('main')
    const cardClima = document.createElement('div')
    
    //funcionalidades:
    
    //tarjeta de buscar
    //ES UN CALLBACK
    const searchCard = createSearchCard(callback)

    
    //pintamos todo en el dom
    container.appendChild(xxxxx)
    return container
}